<?php
	switch ($_REQUEST["acao"]) {
		case 'cadastrar':
			$sql = "INSERT INTO calçados (Fabricante, Modelo, Tamanho , Quantidade, Especificações) VALUES ('".$_POST["Fabricante"]."','".$_POST["Modelo"]."','".$_POST["Tamanho"]."','".$_POST["Quantidade"]."','".$_POST["Especificações"]."')";

			$res = $conn->query($sql) or die($conn->error);

			redirecionarCadastro("consultar-calçado",$res);
		break;
		
		case 'editar':
			$sql = "UPDATE calçados SET
						Fabricante='".$_POST["Fabricante"]."',	
						Modelo='".$_POST["Modelo"]."',
						Tamanho='".$_POST["Tamanho"]."',
						Quantidade='".$_POST["Quantidade"]."',
						Especificações='".$_POST["Especificações"]."'
					WHERE Id_calçado=".$_POST["Id_calçado"];

			$res = $conn->query($sql) or die($conn->error);

			redirecionarEditar("consultar-calçado",$res);
		break;

		case 'excluir':
			$sql = "DELETE FROM calçados WHERE Id_calçado=".$_REQUEST["Id_calçado"];

			$res = $conn->query($sql) or die($conn->error);

			redirecionarExcluir("consultar-calçado",$res);
		break;
	}
?>