<h1>Consultar Aluno</h1>
<?php
	$sql = "SELECT * FROM roupas";
	$res = $conn->query($sql) or die($conn->error);
	$qtd = $res->num_rows;

	if($qtd > 0){
		print "<p>Encontrou <b>".$qtd."</b> resultado(s)";
		print "<div class='table-responsive'>";
		print "<table class='table table-bordered table-striped table-hover'>";
		print "<tr>";
		print "<th>#</th>";
		print "<th>Id_roupa</th>";
		print "<th>Fabricante</th>";
		print "<th>Modelo</th>";
		print "<th>Tamanho</th>";
        print "<th>Sexo</th>";
        print "<th>Tipo</th>";
        print "<th>Quantidade</th>";
        print "<th>Especificações</th>";
		print "<th>Ações</th>";
		print "</tr>";
		while($row = $res->fetch_object()){
			print "<tr>";
			print "<td>".$row->Id_roupa."</td>";
			print "<td>".$row->Fabricante."</td>";
			print "<td>".$row->Modelo."</td>";
			print "<td>".$row->Tamanho."</td>";
			print "<td>".$row->Sexo."</td>";
			print "<td>".$row->Tipo."</td>";
            print "<td>".$row->Quantidade."</td>";
            print "<td>".$row->Especificações."</td>";
            print "<td>
						<button class='btn btn-success' onclick=\"location.href='?page=editar-roupa&Id_roupa=".$row->Id_roupa."';\"><i class='fa fa-edit'></i></button>

						<button class='btn btn-danger' onclick=\"if(confirm('Tem certeza que deseja excluir?')){location.href='?page=salvar-roupa&acao=excluir&Id_roupa=".$row->Id_roupa."';}else{flase;}\"><i class='fa fa-trash'></i></button>
				   </td>";
			print "</tr>";
		}
		print "</table>";
		print "</div>";
	}else{
		print "<div class='alert alert-danger'>Não encontrou resultados</div>";
	}
?>