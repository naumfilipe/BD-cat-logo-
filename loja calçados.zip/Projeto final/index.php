<!DOCTYPE html>
<html lang="pt-BR">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <title>Loja De Roupas E Calçados</title>
    <script src="https://use.fontawesome.com/e506c26381.js"></script>
  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
      <a class="navbar-brand" href="#">Loja De Roupas E Calçados/a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
            <a class="nav-link" href="index.php">Início</a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Calçados
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
              <a class="dropdown-item" href="?page=cadastrar-calçado">Cadastrar</a>
              <a class="dropdown-item" href="?page=consultar-roupa">Consultar</a>
            </div>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Roupas
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
              <a class="dropdown-item" href="?page=cadastrar-roupa">Cadastrar</a>
              <a class="dropdown-item" href="?page=consultar-roupa">Consultar</a>
            </div>
          </li>
        </ul>
      </div>
    </nav>
    <div class="container">
      <div class="row mt-5">
        <div class="col-lg-12">
          <?php
            include("config.php");
            include("functions.php");
            switch (@$_REQUEST["page"]) {
              
              case 'cadastrar-calçado':
                include("cadastrar-calçado.php");
              break;
              
              case 'consultar-calçado':
                include("consultar-calçado.php");
              break;

              case 'editar-calçado':
                include("editar-calçado.php");
              break;  

              case 'salvar-calçado':
                include("salvar-calçado.php");
              break;

              case 'cadastrar-roupa':
                include("cadastrar-roupa.php");
              break;

              case 'consultar-roupa':
                include("consultar-roupa.php");
              break;

              case 'editar-roupa':
                include("editar-roupa.php");
              break;
              
              case 'salvar-roupa':
                include("salvar-roupa.php");
              break;
              
              default:
                include("main.php");
            }
          ?>
        </div>
      </div>
    </div>

    <script src="js/jquery-3.5.1.slim.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>