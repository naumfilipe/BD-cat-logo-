CREATE TABLE IF NOT EXISTS `mydb`.`calçados` (
  `Id_calçado` INTEGER UNSIGNED NOT NULL AUTO_INCREMENT,
  `Fabricante` VARCHAR(200) NULL,
  `Modelo` VARCHAR(200) NULL,
  `Tamanho` DECIMAL NULL,
  `Quantidade` INT NULL,
  `Especificações` VARCHAR(200) NULL)
  PRIMARY KEY(`Id_calçado`)


CREATE TABLE IF NOT EXISTS `mydb`.`roupas` (
  `Id_roupa` INTEGER UNSIGNED NOT NULL AUTO_INCREMENT,
  `Fabricante` VARCHAR(200) NULL,
  `Modelo` VARCHAR(200) NULL,
  `Tamanho` VARCHAR(200) NULL,
  `Sexo` VARCHAR(200) NULL,
  `Tipo` DECIMAL NULL,
  `Quantidade` INT NULL,
  `Especificações` VARCHAR(200) NULL)
  PRIMARY KEY(`Id_roupa`)