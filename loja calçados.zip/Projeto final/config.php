<?php
	define('HOST','localhost');
	define('USER','root');
	define('PASS','');
	define('BASE','Loja De Roupas E Calçados');

	$conn = new MySQLi(HOST,USER,PASS,BASE);
?>