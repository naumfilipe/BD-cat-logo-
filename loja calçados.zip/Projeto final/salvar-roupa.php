<?php
	switch ($_REQUEST["acao"]) {
		case 'cadastrar':
			$sql = "INSERT INTO roupas (Fabricante, Modelo, Tamanho, Sexo, Tipo, Quantidade, Especificações) VALUES ('".$_POST["Fabricante"]."','".$_POST["Modelo"]."','".$_POST["Tamanho"]."','".$_POST["Sexo"]."','".$_POST["Tipo"]."','".$_POST["Quantidade"]."','".$_POST["Especificações"]."')";

			$res = $conn->query($sql) or die($conn->error);

			redirecionarCadastro("consultar-roupa",$res);
		break;
		
		case 'editar':
			$sql = "UPDATE roupa SET
						Fabricante='".$_POST["Fabricante"]."',	
						Modelo='".$_POST["Modelo"]."',
						Tamanho='".$_POST["Tamanho"]."',
						Sexo='".$_POST["Sexo"]."',
						Tipo='".$_POST["Tipo"]."',
                        Quantidade='".$_POST["Quantidade"]."',
                        Especificações='".$_POST["Especificações"]."',
					WHERE Id_roupa=".$_POST["Id_roupa"];

			$res = $conn->query($sql) or die($conn->error);

			redirecionarEditar("consultar-roupa",$res);
		break;

		case 'excluir':
			$sql = "DELETE FROM roupas WHERE Id_roupa=".$_REQUEST["Id_roupa"];

			$res = $conn->query($sql) or die($conn->error);

			redirecionarExcluir("consultar-roupa",$res);
		break;
	}
?>