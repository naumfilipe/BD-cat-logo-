<h1>Editar Calçado</h1>
<?php
	$sql = "SELECT * FROM calçados WHERE Id_calçado=".$_REQUEST["Id_calçado"];

	$res = $conn->query($sql);

	$row = $res->fetch_object();
?>
<form action="?page=salvar-calçado" method="POST">
	<input type="hidden" name="acao" value="editar">
	<input type="hidden" name="Id_calçado" value="<?php print $row->Id_calçado; ?>">
	<div class="form-group">
		<label>Fabricante</label>
		<input type="text" name="Fabricante" class="form-control" value="<?php print $row->Fabricante; ?>">
	</div>
	<div class="form-group">
		<label>Modelo</label>
		<input type="text" name="Modelo" class="form-control" value="<?php print $row->Modelo; ?>">
	</div>
	<div class="form-group">
		<label>Tamanho</label>
		<input type="text" name="Tamanho" class="form-control" value="<?php print $row->Tamanho; ?>">
	</div>
	<div class="form-group">
		<label>Quantidade</label>
		<input type="number" name="Quantidade" class="form-control" value="<?php print $row->Quantidade; ?>">
	</div>
	<div class="form-group">
		<label>Especificações</label>
		<input type="text" name="Especificações" class="form-control" value="<?php print $row->Especificações; ?>">
	</div>
	<div class="form-group">
		<button type="submit" class="btn btn-success">Enviar</button>
	</div>
</form>