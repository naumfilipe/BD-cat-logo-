<h1>Editar Roupa</h1>
<?php
	$sql = "SELECT * FROM roupas WHERE Id_roupa=".$_REQUEST["Id_roupa"];

	$res = $conn->query($sql);

	$row = $res->fetch_object();
?>
<form action="?page=salvar-roupa" method="POST">
	<input type="hidden" name="acao" value="editar">
	<input type="hidden" name="Id_roupa" value="<?php print $row->Id_roupa; ?>">
	<div class="form-group">
		<label>Fabricante</label>
		<input type="text" name="Fabricante" class="form-control" value="<?php print $row->Fabricante; ?>">
	</div>
	<div class="form-group">
		<label>Modelo</label>
		<input type="number" name="Modelo" class="form-control" value="<?php print $row->Modelo; ?>">
	</div>
	<div class="form-group">
		<label>Tamanho</label>
		<input type="date" name="Tamanho" class="form-control" value="<?php print $row->Tamanho; ?>">
	</div>
	<div class="form-group">
		<label>Tipo</label>
		<input type="text" name="Tipo" class="form-control" value="<?php print $row->Tipo; ?>">
	</div>
	<div class="form-group">
		<label>Sexo</label>
		<input type="text" name="Sexo" class="form-control" value="<?php print $row->Sexo; ?>">
    </div>
    <div class="form-group">
        <label>Quantidade</label>
        <input type="number" name="Quantidade" class="form-control" value="<?php print $row->Quantidade; ?>">
    </div>
    <div class="form-group"></div>
        <label>Especificações</label>
        <input type="text" name="Especificações" class="form-control" value="<?php print $row->Especificações; ?>">
    </div>
	<div class="form-group">
		<button type="submit" class="btn btn-success">Enviar</button>
	</div>
</form>