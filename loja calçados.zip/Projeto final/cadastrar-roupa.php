<h1>Cadastrar Roupa</h1>
<form action="?page=salvar-roupa" method="POST">
<input type="hidden" name="acao" value="cadastrar">
	<div class="form-group">
		<label>Fabricante</label>
		<input type="text" name="Fabricante" class="form-control">
	</div>
	<div class="form-group">
		<label>Modelo</label>
		<input type="text" name="Modelo" class="form-control">
	</div>
	<div class="form-group">
		<label>Tamanho</label>
		<input type="text" name="Tamanho" class="form-control">
	</div>
	<div class="form-group">
		<label>Sexo</label>
		<input type="text" name="Sexo" class="form-control">
	</div>
	<div class="form-group">
		<label>Tipo</label>
		<input type="text" name="Tipo" class="form-control">
    </div>
	<div class="form-group">
		<label>Quantidade</label>
		<input type="number" name="Quantidade" class="form-control">
	</div>
	<div class="form-group">
		<label>Especificações</label>
		<input type="text" name="Especificações" class="form-control">
	</div>
	<div class="form-group">
		<button type="submit" class="btn btn-success">Enviar</button>
    </div>
</input>    
</form>