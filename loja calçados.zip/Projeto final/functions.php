<?php
	function redirecionarCadastro($page,$res)
	{
		if($res==true){
			print "<script>alert('Cadastrou com sucesso!');</script>";
			print "<script>location.href='?page=".$page."';</script>";
		}else{
			print "<script>alert('Não foi possível cadastrar!');</script>";
			print "<script>location.href='?page=".$page."';</script>";
		}
		return $page;
	}

	function redirecionarEditar($page,$res)
	{
		if($res==true){
			print "<script>alert('Editou com sucesso!');</script>";
			print "<script>location.href='?page=".$page."';</script>";
		}else{
			print "<script>alert('Não foi possível editar!');</script>";
			print "<script>location.href='?page=".$page."';</script>";
		}
		return $page;
	}

	function redirecionarExcluir($page,$res)
	{
		if($res==true){
			print "<script>alert('Excluiu com sucesso!');</script>";
			print "<script>location.href='?page=".$page."';</script>";
		}else{
			print "<script>alert('Não foi possível excluir!');</script>";
			print "<script>location.href='?page=".$page."';</script>";
		}
		return $page;
	}