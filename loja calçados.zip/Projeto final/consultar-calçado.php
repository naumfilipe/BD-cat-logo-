<h1>Consultar Calçado</h1>
<?php
	$sql = "SELECT * FROM calçados";
	$res = $conn->query($sql) or die($conn->error);
	$qtd = $res->num_rows;

	if($qtd > 0){
		print "<p>Encontrou <b>".$qtd."</b> resultado(s)";
		print "<div class='table-responsive'>";
		print "<table class='table table-bordered table-striped table-hover'>";
		print "<tr>";
		print "<th>#</th>";
		print "<th>Fabricante</th>";
		print "<th>Modelo</th>";
		print "<th>Tamanho</th>";
		print "<th>Quantidade</th>";
		print "<th>Especificações</th>";
		print "<th>Ações</th>";
		print "</tr>";
		while($row = $res->fetch_object()){
			print "<tr>";
			print "<td>".$row->Id_calçado."</td>";
			print "<td>".$row->Fabricante."</td>";
			print "<td>".$row->Modelo."</td>";
			print "<td>".$row->Tamanho."</td>";
			print "<td>".$row->Quantidade."</td>";
			print "<td>".$row->Especificações."</td>";
			print "<td>
						<button class='btn btn-success' onclick=\"location.href='?page=editar-calçado&Id_calçado=".$row->Id_calçado."';\"><i class='fa fa-edit'></i></button>

						<button class='btn btn-danger' onclick=\"if(confirm('Tem certeza que deseja excluir?')){location.href='?page=salvar-calçado&acao=excluir&Id_calçado=".$row->Id_calçado."';}else{flase;}\"><i class='fa fa-trash'></i></button>
				   </td>";
			print "</tr>";
		}
		print "</table>";
		print "</div>";
	}else{
		print "<div class='alert alert-danger'>Não encontrou resultados</div>";
	}
?>